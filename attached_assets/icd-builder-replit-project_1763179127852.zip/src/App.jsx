import React, { useState } from "react";
import FieldBrowser from "./components/FieldBrowser";
import MappingTable from "./components/MappingTable";
import { parseCsvFile } from "./lib/csv";

function normalizeField(row) {
  const system = row.system || row.System || row.system_name || "";
  const object = row.object || row.Object || row.business_object || "";
  const field = row.field || row.Field || row.field_name || "";
  const data_type = row.data_type || row.type || "";
  const requiredRaw = row.required || row.Required || "";
  const key_type = row.key_type || row.KeyType || row.key || "";

  const required =
    typeof requiredRaw === "string"
      ? ["y", "yes", "true", "1"].includes(requiredRaw.toLowerCase())
      : !!requiredRaw;

  return {
    id: `${system}.${object}.${field}`,
    system,
    object,
    field,
    data_type,
    required,
    key_type,
    description: row.description || row.Description || "",
  };
}

function exportMappingsCsv(mappings) {
  const header = [
    "flow_id",
    "source_system",
    "source_object",
    "source_field",
    "source_type",
    "source_key_type",
    "target_system",
    "target_object",
    "target_field",
    "target_type",
    "target_key_type",
    "transform_rule",
    "notes",
  ];
  const rows = mappings.map((m) => [
    m.flow_id || "",
    m.source_system,
    m.source_object,
    m.source_field,
    m.source_type,
    m.source_key_type || "",
    m.target_system,
    m.target_object,
    m.target_field,
    m.target_type,
    m.target_key_type || "",
    m.transform_rule || "",
    m.notes || "",
  ]);
  const csv = [header, ...rows].map((r) => r.join(",")).join("\n");
  const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = "icd_mappings_export.csv";
  a.click();
  URL.revokeObjectURL(url);
}

export default function App() {
  const [fields, setFields] = useState([]);
  const [sourceSystem, setSourceSystem] = useState("");
  const [sourceObject, setSourceObject] = useState("");
  const [targetSystem, setTargetSystem] = useState("");
  const [targetObject, setTargetObject] = useState("");
  const [mappings, setMappings] = useState([]);
  const [flowId, setFlowId] = useState("flow_01");

  const handleCatalogUpload = async (e) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const result = await parseCsvFile(file);
    const normalized = result.data
      .map(normalizeField)
      .filter((f) => f.system && f.object && f.field);
    setFields(normalized);
  };

  const handleAddFieldToMapping = (field, side) => {
    const updated = [...mappings];
    const idx = updated.findIndex((m) =>
      side === "source" ? !m.source_id : !m.target_id
    );
    const label = `${field.object}.${field.field}`;
    if (idx === -1) {
      const base = {
        flow_id: flowId,
        source_id: "",
        source_system: "",
        source_object: "",
        source_field: "",
        source_label: "",
        source_type: "",
        source_required: false,
        source_key_type: "",
        target_id: "",
        target_system: "",
        target_object: "",
        target_field: "",
        target_label: "",
        target_type: "",
        target_required: false,
        target_key_type: "",
        transform_rule: "",
        notes: "",
      };
      const row = { ...base };
      if (side === "source") {
        row.source_id = field.id;
        row.source_system = field.system;
        row.source_object = field.object;
        row.source_field = field.field;
        row.source_label = label;
        row.source_type = field.data_type;
        row.source_required = field.required;
        row.source_key_type = field.key_type;
      } else {
        row.target_id = field.id;
        row.target_system = field.system;
        row.target_object = field.object;
        row.target_field = field.field;
        row.target_label = label;
        row.target_type = field.data_type;
        row.target_required = field.required;
        row.target_key_type = field.key_type;
      }
      updated.push(row);
    } else {
      const row = { ...updated[idx] };
      if (side === "source") {
        row.source_id = field.id;
        row.source_system = field.system;
        row.source_object = field.object;
        row.source_field = field.field;
        row.source_label = label;
        row.source_type = field.data_type;
        row.source_required = field.required;
        row.source_key_type = field.key_type;
      } else {
        row.target_id = field.id;
        row.target_system = field.system;
        row.target_object = field.object;
        row.target_field = field.field;
        row.target_label = label;
        row.target_type = field.data_type;
        row.target_required = field.required;
        row.target_key_type = field.key_type;
      }
      updated[idx] = row;
    }
    setMappings(updated);
  };

  const fieldsForSource = fields;
  const fieldsForTarget = fields;

  return (
    <div className="app-root">
      <header className="app-header">
        <h1>ICD Builder · BOO Integration Layer</h1>
        <div className="header-actions">
          <label className="file-input-label">
            Load fields_catalog CSV
            <input
              type="file"
              accept=".csv,text/csv"
              onChange={handleCatalogUpload}
            />
          </label>
          <div className="flow-id-input">
            <span>Flow ID</span>
            <input
              type="text"
              value={flowId}
              onChange={(e) => setFlowId(e.target.value)}
            />
          </div>
          <button
            type="button"
            onClick={() => exportMappingsCsv(mappings)}
            disabled={mappings.length === 0}
          >
            Export ICD CSV
          </button>
        </div>
      </header>
      <main className="app-main">
        <div className="columns">
          <FieldBrowser
            title="Source Fields"
            system={sourceSystem}
            objectFilter={sourceObject}
            fields={fieldsForSource}
            onSystemChange={setSourceSystem}
            onObjectFilterChange={setSourceObject}
            onAddField={(f) => handleAddFieldToMapping(f, "source")}
          />
          <MappingTable
            mappings={mappings}
            onUpdate={setMappings}
            onRemove={(idx) =>
              setMappings(mappings.filter((_, i) => i !== idx))
            }
          />
          <FieldBrowser
            title="Target Fields"
            system={targetSystem}
            objectFilter={targetObject}
            fields={fieldsForTarget}
            onSystemChange={setTargetSystem}
            onObjectFilterChange={setTargetObject}
            onAddField={(f) => handleAddFieldToMapping(f, "target")}
          />
        </div>
      </main>
      <style>{`
        :root {
          font-family: system-ui, -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif;
        }
        body {
          margin: 0;
        }
        .app-root {
          min-height: 100vh;
          display: flex;
          flex-direction: column;
          background: #050816;
          color: #f9fafb;
        }
        .app-header {
          padding: 16px 24px;
          border-bottom: 1px solid rgba(148, 163, 184, 0.4);
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          background: radial-gradient(circle at top left, #22d3ee33, transparent 60%);
        }
        .app-header h1 {
          font-size: 18px;
          font-weight: 600;
          margin: 0;
        }
        .header-actions {
          display: flex;
          align-items: center;
          gap: 12px;
          flex-wrap: wrap;
        }
        .file-input-label {
          position: relative;
          overflow: hidden;
          display: inline-flex;
          align-items: center;
          padding: 6px 12px;
          font-size: 12px;
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.6);
          cursor: pointer;
          background: rgba(15, 23, 42, 0.9);
        }
        .file-input-label input {
          position: absolute;
          inset: 0;
          opacity: 0;
          cursor: pointer;
        }
        .flow-id-input {
          display: inline-flex;
          align-items: center;
          gap: 6px;
          font-size: 12px;
        }
        .flow-id-input input {
          background: rgba(15, 23, 42, 0.9);
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.6);
          padding: 4px 8px;
          color: #e5e7eb;
          min-width: 80px;
        }
        .app-header button {
          padding: 6px 14px;
          border-radius: 999px;
          border: none;
          background: linear-gradient(to right, #22c55e, #22d3ee);
          color: #020617;
          font-size: 12px;
          font-weight: 600;
          cursor: pointer;
        }
        .app-header button:disabled {
          opacity: 0.4;
          cursor: default;
        }
        .app-main {
          flex: 1;
          padding: 16px 16px 24px;
        }
        .columns {
          display: grid;
          grid-template-columns: minmax(0, 1.2fr) minmax(0, 2fr) minmax(0, 1.2fr);
          gap: 16px;
        }
        .panel {
          background: radial-gradient(circle at top left, #0f172a, #020617);
          border-radius: 16px;
          border: 1px solid rgba(148, 163, 184, 0.4);
          display: flex;
          flex-direction: column;
          min-height: 0;
        }
        .panel-header {
          padding: 10px 12px;
          border-bottom: 1px solid rgba(148, 163, 184, 0.3);
        }
        .panel-header h3 {
          margin: 0;
          font-size: 13px;
          font-weight: 600;
          letter-spacing: 0.02em;
          text-transform: uppercase;
          color: #e5e7eb;
        }
        .panel-body {
          padding: 10px;
          flex: 1;
          display: flex;
          flex-direction: column;
          min-height: 0;
        }
        .field-row {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 8px;
          margin-bottom: 8px;
          font-size: 12px;
        }
        .field-row label {
          color: #9ca3af;
        }
        .field-row select {
          flex: 1;
          background: rgba(15, 23, 42, 0.9);
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.6);
          padding: 4px 8px;
          color: #e5e7eb;
        }
        .field-list {
          margin-top: 4px;
          flex: 1;
          overflow: auto;
          display: flex;
          flex-direction: column;
          gap: 4px;
        }
        .field-pill {
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.4);
          background: rgba(15, 23, 42, 0.8);
          color: #e5e7eb;
          padding: 4px 8px;
          display: flex;
          align-items: center;
          justify-content: space-between;
          font-size: 11px;
          cursor: pointer;
        }
        .field-pill-name {
          font-weight: 500;
        }
        .field-pill-meta {
          font-size: 10px;
          color: #9ca3af;
        }
        .empty-hint {
          font-size: 12px;
          color: #9ca3af;
          margin-top: 4px;
        }
        .mapping-table {
          width: 100%;
          border-collapse: collapse;
          font-size: 11px;
        }
        .mapping-table th,
        .mapping-table td {
          border-bottom: 1px solid rgba(51, 65, 85, 0.9);
          padding: 6px 4px;
          vertical-align: top;
        }
        .mapping-table th {
          text-align: left;
          color: #9ca3af;
          font-weight: 500;
        }
        .mapping-table input,
        .mapping-table select {
          width: 100%;
          box-sizing: border-box;
          background: rgba(15, 23, 42, 0.9);
          border-radius: 999px;
          border: 1px solid rgba(148, 163, 184, 0.6);
          padding: 2px 6px;
          color: #e5e7eb;
          font-size: 11px;
        }
        .cell-main {
          font-weight: 500;
        }
        .cell-sub {
          font-size: 10px;
          color: #9ca3af;
        }
        .status-badge {
          display: inline-flex;
          align-items: center;
          padding: 2px 6px;
          border-radius: 999px;
          font-size: 10px;
        }
        .status-ok {
          background: rgba(22, 163, 74, 0.1);
          color: #4ade80;
        }
        .status-warning {
          background: rgba(234, 179, 8, 0.08);
          color: #facc15;
        }
        .status-error {
          background: rgba(220, 38, 38, 0.1);
          color: #fb7185;
        }
        .icon-button {
          border: none;
          background: transparent;
          color: #9ca3af;
          cursor: pointer;
        }
        .mapping-panel {
          min-height: 320px;
        }
        @media (max-width: 1024px) {
          .columns {
            grid-template-columns: minmax(0, 1fr);
          }
        }
      `}</style>
    </div>
  );
}
