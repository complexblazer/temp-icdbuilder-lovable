import React from "react";

export default function FieldBrowser({
  title,
  system,
  objectFilter,
  fields,
  onSystemChange,
  onObjectFilterChange,
  onAddField,
}) {
  const systems = Array.from(new Set(fields.map((f) => f.system))).sort();

  const objects = Array.from(
    new Set(
      fields
        .filter((f) => !system || f.system === system)
        .map((f) => f.object)
    )
  ).sort();

  const filteredFields = fields.filter((f) => {
    if (system && f.system !== system) return false;
    if (objectFilter && f.object !== objectFilter) return false;
    return true;
  });

  return (
    <div className="panel">
      <div className="panel-header">
        <h3>{title}</h3>
      </div>
      <div className="panel-body">
        <div className="field-row">
          <label>System</label>
          <select value={system} onChange={(e) => onSystemChange(e.target.value)}>
            <option value="">All</option>
            {systems.map((s) => (
              <option key={s} value={s}>
                {s}
              </option>
            ))}
          </select>
        </div>
        <div className="field-row">
          <label>Object</label>
          <select
            value={objectFilter}
            onChange={(e) => onObjectFilterChange(e.target.value)}
          >
            <option value="">All</option>
            {objects.map((o) => (
              <option key={o} value={o}>
                {o}
              </option>
            ))}
          </select>
        </div>
        <div className="field-list">
          {filteredFields.map((f) => (
            <button
              type="button"
              key={f.id}
              className="field-pill"
              onClick={() => onAddField(f)}
              title={f.description || ""}
            >
              <span className="field-pill-name">{f.object}.{f.field}</span>
              <span className="field-pill-meta">
                {f.data_type} · {f.key_type || "key?"}
              </span>
            </button>
          ))}
          {filteredFields.length === 0 && (
            <div className="empty-hint">No fields for this filter.</div>
          )}
        </div>
      </div>
    </div>
  );
}
