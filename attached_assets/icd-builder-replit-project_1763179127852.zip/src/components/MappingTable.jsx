import React from "react";

const TRANSFORM_RULES = [
  "identity",
  "enum_lookup",
  "cnl_resolve",
  "string_to_number",
  "number_to_string",
  "compose",
  "uppercase",
  "lowercase",
];

export default function MappingTable({ mappings, onUpdate, onRemove }) {
  const handleChange = (index, field, value) => {
    const updated = [...mappings];
    updated[index] = { ...updated[index], [field]: value };
    onUpdate(updated);
  };

  const validateRow = (row) => {
    const issues = [];
    if (!row.source_id) issues.push("Missing source");
    if (!row.target_id) issues.push("Missing target");
    if (row.source_type && row.target_type && row.source_type !== row.target_type) {
      issues.push("Type mismatch");
    }
    if (row.source_required && !row.target_required) {
      issues.push("Required → optional");
    }
    return issues;
  };

  return (
    <div className="panel mapping-panel">
      <div className="panel-header">
        <h3>Mappings</h3>
      </div>
      <div className="panel-body">
        {mappings.length === 0 ? (
          <div className="empty-hint">
            Click a field on the left or right to seed a mapping row.
          </div>
        ) : (
          <table className="mapping-table">
            <thead>
              <tr>
                <th>Source Field</th>
                <th>Type</th>
                <th>Target Field</th>
                <th>Type</th>
                <th>Transform Rule</th>
                <th>Notes</th>
                <th>Status</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {mappings.map((row, idx) => {
                const issues = validateRow(row);
                const severity = issues.some((i) => i.includes("Missing"))
                  ? "error"
                  : issues.length
                  ? "warning"
                  : "ok";
                return (
                  <tr key={idx}>
                    <td>
                      <div className="cell-main">{row.source_label}</div>
                      <div className="cell-sub">
                        {row.source_system} · {row.source_object}
                      </div>
                    </td>
                    <td>{row.source_type}</td>
                    <td>
                      <div className="cell-main">{row.target_label}</div>
                      <div className="cell-sub">
                        {row.target_system} · {row.target_object}
                      </div>
                    </td>
                    <td>{row.target_type}</td>
                    <td>
                      <select
                        value={row.transform_rule || ""}
                        onChange={(e) =>
                          handleChange(idx, "transform_rule", e.target.value)
                        }
                      >
                        <option value="">(none)</option>
                        {TRANSFORM_RULES.map((r) => (
                          <option key={r} value={r}>
                            {r}
                          </option>
                        ))}
                      </select>
                    </td>
                    <td>
                      <input
                        type="text"
                        value={row.notes || ""}
                        onChange={(e) =>
                          handleChange(idx, "notes", e.target.value)
                        }
                      />
                    </td>
                    <td>
                      <span className={`status-badge status-${severity}`}>
                        {severity === "ok"
                          ? "Valid"
                          : issues.join("; ")}
                      </span>
                    </td>
                    <td>
                      <button
                        type="button"
                        className="icon-button"
                        onClick={() => onRemove(idx)}
                        title="Remove"
                      >
                        ✕
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
